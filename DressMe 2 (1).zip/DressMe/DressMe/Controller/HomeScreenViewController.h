//
//  HomeScreenViewController.h
//  DressMe
//  abuomar@usc.edu
//  Created by Jamila Abu-Omar on 12/5/17.
//  Copyright © 2017 Jamila Abu-Omar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JSWeather.h"

//home screen view controller

@interface HomeScreenViewController : UIViewController

@property (weak, nonatomic) NSString *username;
@property (weak, nonatomic) NSString *password;

@end
