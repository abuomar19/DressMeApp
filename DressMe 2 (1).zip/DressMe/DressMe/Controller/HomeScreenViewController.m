//
//  HomeScreenViewController.m
//  DressMe
//  abuomar@usc.edu
//  Created by Jamila Abu-Omar on 12/5/17.
//  Copyright © 2017 Jamila Abu-Omar. All rights reserved.
//

#import "HomeScreenViewController.h"
#import "ViewController.h"
#import "WardrobeModel.h"
#import "JSDailyForecastObject.h"
#import "JSWeather.h"

@interface HomeScreenViewController () <JSWeatherDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *topImage2;
@property (weak, nonatomic) IBOutlet UIImageView *bottomImage1;
@property (weak, nonatomic) IBOutlet UIImageView *bottomImage2;
@property (weak, nonatomic) IBOutlet UIImageView *topImage1;
@property(weak, nonatomic) WardrobeModel *wardrobe;
@property (strong, nonatomic) JSWeather *weather;
@property (strong, nonatomic) NSString * city;
@property (strong, nonatomic) NSString * state;
@property float highOfDay;

@end

@implementation HomeScreenViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //if(_username == nil){
    // [self performSegueWithIdentifier: @"segueId" sender: self];
    //}
    _wardrobe = [WardrobeModel sharedModel];
    //check if any wardrobe article of clothing does not have an owner,
    //if it doesn't then make username the owner
    for(int i = 0; i < [_wardrobe numberOfClothes]; i++){
        if([[_wardrobe clothingAtIndex:i].owner isEqualToString:@""]){
            [_wardrobe clothingAtIndex:1].owner = _username;
        }
    }
    
    //get weather from api (get location also)
    JSWeather *weather = [JSWeather sharedInstance];
    [weather setTemperatureMetric:kJSFahrenheit];
    [weather setDelegate:self];
    [weather getCurrentLocation];
    NSLog(@"completed making weather js thing");
    
}

- (IBAction)creatOutfitButtonPressed:(UIButton *)sender {
    //now decide what best clothing is for the date
    //if above 75 and less than 85 get shirt and shorts with shoes
    if(75.0 <= _highOfDay <85.0){
        for(int i = 0; i < [_wardrobe numberOfClothes];i++){
            if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"shirt"]){
                _topImage2.image = [_wardrobe clothingAtIndex:i].image;
            }
            if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"shorts"]){
                _bottomImage2.image = [_wardrobe clothingAtIndex:i].image;
            }
            if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"shoes"]){
                _bottomImage1.image = [_wardrobe clothingAtIndex:i].image;
            }
        }
    }
    
    //if above 85 get shirt and shorts with sandles
    
    else if(85.0 <= _highOfDay ){
        for(int i = 0; i < [_wardrobe numberOfClothes];i++){
            if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"shirt"]){
                _topImage2.image = [_wardrobe clothingAtIndex:i].image;
            }
            if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"shorts"]){
                _bottomImage2.image = [_wardrobe clothingAtIndex:i].image;
            }
            if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"sandals"]){
                _bottomImage1.image = [_wardrobe clothingAtIndex:i].image;
            }
        }
    }
    
    //if below 75 and greater than 60 get shirt and sweater and pants and shoes
    
   else if(60.0 <= _highOfDay < 75.0){
        for(int i = 0; i < [_wardrobe numberOfClothes];i++){
            if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"shirt"]){
                _topImage2.image = [_wardrobe clothingAtIndex:i].image;
            }
            else if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"sweater"]){
                _topImage1.image = [_wardrobe clothingAtIndex:i].image;
            }
           else if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"pants"]){
                _bottomImage2.image = [_wardrobe clothingAtIndex:i].image;
            }
            else if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"shoes"]){
                _bottomImage1.image = [_wardrobe clothingAtIndex:i].image;
            }
        }
    }
    
    //if below 60 and greater than 40  get shirt and jacket and pants and shoes
   else if(40.0 <= _highOfDay < 60.0){
       for(int i = 0; i < [_wardrobe numberOfClothes];i++){
           if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"shirt"]){
               _topImage2.image = [_wardrobe clothingAtIndex:i].image;
           }
           if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"jacket"]){
               _topImage1.image = [_wardrobe clothingAtIndex:i].image;
           }
           if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"pants"]){
               _bottomImage2.image = [_wardrobe clothingAtIndex:i].image;
           }
           if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"shoes"]){
               _bottomImage1.image = [_wardrobe clothingAtIndex:i].image;
           }
       }
   }
    
    //if below 40 get sweater and jacket and pants and boots
    
   else {
       for(int i = 0; i < [_wardrobe numberOfClothes];i++){
           if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"sweater"]){
               _topImage2.image = [_wardrobe clothingAtIndex:i].image;
           }
           if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"jacket"]){
               _topImage1.image = [_wardrobe clothingAtIndex:i].image;
           }
           if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"pants"]){
               _bottomImage2.image = [_wardrobe clothingAtIndex:i].image;
           }
           if([[_wardrobe clothingAtIndex:i].type isEqualToString:@"boots"]){
               _bottomImage1.image = [_wardrobe clothingAtIndex:i].image;
           }
       }
   }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"loginSuccessfulSegue"]){
        HomeScreenViewController *home = [segue destinationViewController];
        ViewController *login = [segue sourceViewController];
        login.completionHandler = ^( NSString *username, NSString *password){
            home.username = username;
            home.password = password;
            NSLog(@"username : ,%@", username);
       };
    }
}
//
- (void)JSWeather:(JSWeather *)weather didReceiveCurrentLocation:(NSDictionary *)dict
{
    NSLog(@"entered JSWeather weather didreceivecurrentLocation");
    _city = [dict objectForKey:@"city"];
    _state = [dict objectForKey:@"state"];
    NSLog(@"City and State , %@ %@", _city, _state);
    
    
    [weather queryForCurrentWeatherWithCity:_city state:_state block:^(JSCurrentWeatherObject *object, NSError *error) {
        NSLog(@"queryfor current weather ");
        if (error) {
             NSLog(@"got in here due to error in api weather" );
            [[[UIAlertView alloc] initWithTitle:@"Error" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"Okay" otherButtonTitles:nil] show];
            return;
        }
        else{
            NSLog(@"high of day : %f", object.JSTemporaryMaxTemperature);
            _highOfDay = object.JSTemporaryMaxTemperature;
        }
    }];
}

- (void)JSWeather:(JSWeather *)weather didReceiveCurrentLocationError:(NSError *)error
{
    NSLog(@"finished recieving location but failed");
    NSLog(@"%@", error);
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
