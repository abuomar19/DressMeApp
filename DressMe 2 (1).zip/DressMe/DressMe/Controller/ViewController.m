//
//  ViewController.m
//  DressMe
//  abuomar@usc.edu
//  Created by Jamila Abu-Omar on 11/24/17.
//  Copyright © 2017 Jamila Abu-Omar. All rights reserved.
//

#import "ViewController.h"
#import "HomeScreenViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UITextField *usernameField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;
@property NSMutableDictionary *loginCredentials;
@property (weak, nonatomic) IBOutlet UILabel *errorLabel;


@end

NSString *const kLoginKey = @"LoginDictionary";

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //make text field for username first responder
    [self.usernameField becomeFirstResponder];
    //grab stuff from userdefaults (usernames and passwords)
    //NSUserDefaults *standardDefaults = [NSUserDefaults standardUserDefaults];
    NSDictionary * tempLoginCredentials= [[NSUserDefaults standardUserDefaults] objectForKey:kLoginKey];
    //if there is already stuff then keep it set that way
    if(tempLoginCredentials){
        _loginCredentials = [tempLoginCredentials mutableCopy];
    }
    //else if no defaults then create empty dictionary
    else{
         _loginCredentials = [[NSMutableDictionary alloc] initWithObjects:[NSArray arrayWithObjects:@"password", nil] forKeys:[NSArray arrayWithObjects:@"username", nil]];
    }
    _passwordField.secureTextEntry = YES;
}


//using user defaults to keep login credentials on device
-(void)save{
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    
    [defaults setObject:_loginCredentials forKey:kLoginKey];
    [defaults synchronize];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)loginClicked:(UIButton *)sender {
    //checks to see if both textfields are correctly filled
    if(_usernameField.text.length > 0 && _passwordField.text.length > 0 ){
        //then check to see if the username is in the system
        if([_loginCredentials objectForKey:_usernameField.text] != nil){
            //then if it is see if password matches
            if([[_loginCredentials objectForKey: _usernameField.text]isEqualToString: _passwordField.text]){
                //can login now so no error anymore
                _errorLabel.text = @"";
                
                //can segue into next screen
                //update completionHandler
                if(self.completionHandler){
                    self.completionHandler(self.usernameField.text, self.passwordField.text);
                }
                self.passwordField.text = @"";
                self.usernameField.text = @"";
                [self performSegueWithIdentifier:@"loginSuccessfulSegue" sender:sender];
            }
        }
    }
    //it did not work so now print out error message and let them fix it
     _errorLabel.text = @"not valid user login credentials retry";
}

- (IBAction)createUserClicked:(UIButton *)sender {
    //checks to see if both textfields are correctly filled
    if(_usernameField.text.length > 0 && _passwordField.text.length > 0 ){
        //then check to see if the username is in the system
        if([_loginCredentials objectForKey:_usernameField.text] == nil){
            //can create the user than
            //do not forget to save to NSUserDefaults
            NSDictionary *newinfo = [[NSDictionary alloc] initWithObjects:[NSArray arrayWithObjects:_passwordField.text, nil] forKeys:[NSArray arrayWithObjects:_usernameField.text, nil]];
            [_loginCredentials addEntriesFromDictionary:newinfo];
            [self save];
            //can login now so no error anymore
            _errorLabel.text = @"";
            
            //now segue into next screen
            if(self.completionHandler){
                self.completionHandler(self.usernameField.text, self.passwordField.text);
            }
            self.passwordField.text = @"";
            self.usernameField.text = @"";
            [self performSegueWithIdentifier:@"loginSuccessfulSegue" sender:self];
            
        }
    }
    //it did not work so now print out error message and let them fix it
    _errorLabel.text = @"not valid user login credentials retry";
    
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    
    //update completionHandler
    if(self.completionHandler){
        self.completionHandler(self.usernameField.text, self.passwordField.text);
    }
    self.passwordField.text = @"";
    self.usernameField.text = @"";
    return YES;
}



-(BOOL) textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
//    NSString *changedString = [textField.text stringByReplacingCharactersInRange:range withString: string];
    
    return YES;
}


@end
