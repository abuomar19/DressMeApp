//
//  WardrobeTableViewController.h
//  DressMe
//  abuomar@usc.edu
//  Created by Jamila Abu-Omar on 12/5/17.
//  Copyright © 2017 Jamila Abu-Omar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WardrobeTableViewController : UITableViewController

@end
