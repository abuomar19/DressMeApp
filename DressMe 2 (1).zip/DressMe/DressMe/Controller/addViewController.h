//
//  addViewController.h
//  DressMe
//  abuomar@usc.edu
//  Created by Jamila Abu-Omar on 12/5/17.
//  Copyright © 2017 Jamila Abu-Omar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ClothesModel.h"
#import <Photos/Photos.h>

//typedef void (^ALAssetsLibraryWriteImageCompletionBlock)(NSURL *assetURL, NSError *error);
//view controller for adding clothing

typedef void(^AddViewControllerCompletionHandler)(ClothesModel * clothing);

@interface addViewController : UIViewController

@property (copy, nonatomic) AddViewControllerCompletionHandler completionHandler;

@end
