//
//  addViewController.m
//  DressMe
//  abuomar@usc.edu
//  Created by Jamila Abu-Omar on 12/5/17.
//  Copyright © 2017 Jamila Abu-Omar. All rights reserved.
//

#import "../Model/UIImageAndNSCoder.h"
#import "addViewController.h"



@interface addViewController () <UITextFieldDelegate, UITextViewDelegate, UIImagePickerControllerDelegate,UINavigationControllerDelegate, UIPickerViewDelegate, UIPickerViewDataSource>

@property (weak, nonatomic) IBOutlet UIImageView *pictureView;
@property (weak, nonatomic) NSString *type;
@property (weak, nonatomic) NSString *color;
@property (weak, nonatomic) IBOutlet UIButton *Submit;
@property (strong, nonatomic) UIImageAndNSCoder * image;
@property (strong, nonatomic) UIImagePickerController * imagePicker;
@property BOOL isTypePicker;
@property (weak, nonatomic) IBOutlet UIPickerView *picker;
@property (strong, nonatomic) NSArray *typeData;
@property (strong, nonatomic) NSArray *colorData;
@property (weak, nonatomic) IBOutlet UIButton *pickTypeButton;
@property (weak, nonatomic) IBOutlet UIButton *pickColorButton;
@property (weak, nonatomic) NSString * owner;

@end

@implementation addViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //initialize the typeData and colorData
    _typeData = [[NSArray alloc]initWithObjects:@"shirt", @"pants", @"shoes",@"boots",@"sandals",@"shorts",@"jacket",@"sweater", nil];
    _colorData =[[NSArray alloc]initWithObjects:@"white", @"black", @"grey", @"brown", @"green",@"yellow", @"blue", @"orange", @"red", @"pink", @"purple", nil];
    //initialize bool
    _isTypePicker = NO;
    
    //initialize image to null
    _image = nil;
    
    //set two buttons that show color and type as disabled
    [_pickTypeButton setEnabled:NO];
     [_pickColorButton setEnabled:NO];
    
    //connect delegate and source for picker
    self.picker.dataSource = self;
    self.picker.delegate = self;
    
    //check if can now submit
    [self enableOrDisableSaveButton];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)pickPhoto:(UIButton *)sender {
    _imagePicker = [[UIImagePickerController alloc] init];
    _imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    _imagePicker.delegate = self;
    _imagePicker.allowsEditing = YES;
    [self presentViewController:_imagePicker animated:YES completion:nil];
    
    //now save the image into the button maboby
    UIImage *buttonImage = _image;
    _pictureView.image =buttonImage;
    
    
    //check if can now submit
    [self enableOrDisableSaveButton];
}
- (IBAction)takePhoto:(UIButton *)sender {
    _imagePicker = [[UIImagePickerController alloc] init];
    _imagePicker.delegate = self;
    _imagePicker.allowsEditing = YES;
    _imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:_imagePicker animated:YES completion:NULL];
    
    
    //resize image to fit button
    UIImage *scaledImage = [self scaleToSize:CGSizeMake(240.0, 128.0) Image: _image];
    
    //now save the image into the button maboby
    _pictureView.image =scaledImage;
    //saves picture you took into photo library
    UIImageWriteToSavedPhotosAlbum(scaledImage, nil, nil, nil);
   
    
    //check if can now submit
    [self enableOrDisableSaveButton];
}
//helper function to resize image
-(UIImage*)scaleToSize:(CGSize)size Image: (UIImage*) image
{
    // Create a bitmap graphics context
    // This will also set it as the current context
    UIGraphicsBeginImageContext(size);
    
    // Draw the scaled image in the current context
    [image drawInRect:CGRectMake(0, 0, size.width, size.height)];
    
    // Create a new image from current context
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    
    // Pop the current context from the stack
    UIGraphicsEndImageContext();
    
    // Return our new scaled image
    return scaledImage;
}

//helper function to set image to picked image and update view button
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    if (_imagePicker) {
        self.image = [info objectForKey:UIImagePickerControllerEditedImage];
        self.pictureView.image = self.image;
    }
    
    [self enableOrDisableSaveButton];
    
    [self dismissViewControllerAnimated:YES completion:nil];
}


// Helper method
- (void)enableOrDisableSaveButton{
    NSLog(@"color and ect.. %@,%@,%@",_type,_color,_image);
    // Validate the input and enable or disable save button accordingly
    if (self.type.length > 0 && self.color.length > 0 && self.image != nil){
        self.owner = @"";
        self.Submit.enabled = YES;
    } else{
        self.Submit.enabled = NO;
    }
    
}

- (IBAction)submitPressed:(UIButton *)sender {
    ClothesModel * clothing = [[ClothesModel alloc] initWithType: _type color: _color imageName: _image owner: _owner];
    self.completionHandler(clothing);
}

- (IBAction)cancelPressed:(UIButton *)sender {
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (NSInteger)numberOfComponentsInPickerView:(nonnull UIPickerView *)pickerView {
    return 2;
}

- (NSInteger)pickerView:(nonnull UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if(component ==1){
        return _typeData.count;
    }
    return _colorData.count;
}


- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{   if(component ==1){
        return _typeData[row];
    }
        return _colorData[row];
}

#pragma mark PickerView Delegate

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if(component ==1){
        _type = _typeData[row];
        [_pickTypeButton setTitle:_type forState:UIControlStateNormal];
    }else{
        _color = _colorData[row];
        [_pickColorButton setTitle:_color forState:UIControlStateNormal];
    }
    [self enableOrDisableSaveButton];
    
}


@end
