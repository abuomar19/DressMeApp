//
//  ClothesModel.h
//  DressMe
//  abuomar@usc.edu
//  Created by Jamila Abu-Omar on 12/5/17.
//  Copyright © 2017 Jamila Abu-Omar. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "UIImageAndNSCoder.h"

@interface ClothesModel : NSObject
@property (nonatomic, strong) NSString *type;
@property (nonatomic, strong) NSString *color;
@property (nonatomic, strong) UIImageAndNSCoder *image;
@property (nonatomic, strong) NSString * owner;


- (instancetype) initWithType: (NSString *)type
                color:(NSString *) color
            imageName: (UIImageAndNSCoder *)image
                        owner: (NSString *) owner;

-(void) setOwner:(NSString *)owner;

@end
