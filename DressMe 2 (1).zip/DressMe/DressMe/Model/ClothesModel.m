//
//  ClothesModel.m
//  DressMe
//  abuomar@usc.edu
//  Created by Jamila Abu-Omar on 12/5/17.
//  Copyright © 2017 Jamila Abu-Omar. All rights reserved.
//

#import "ClothesModel.h"


//clothes model-holding data of each clothing piece

@implementation ClothesModel

- (instancetype) initWithType: (NSString *)type
                color:(NSString *) color
            imageName: (UIImageAndNSCoder *)image
                        owner: (NSString *) owner{
    _type = type;
    _color = color;
    _image = image;
    _owner = owner;
    return self;
}

-(void) setOwner:(NSString *)owner{
    _owner = owner;
}

@end
