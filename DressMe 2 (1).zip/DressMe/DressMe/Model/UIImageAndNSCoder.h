//
//  UIImageAndNSCoder.h
//  DressMe
//  abuomar@usc.edu
//  Created by Jamila Abu-Omar on 12/7/17.
//  Copyright © 2017 Jamila Abu-Omar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import<Foundation/Foundation.h>

//allows me to store images in plist

@interface UIImageAndNSCoder : UIImage

- (void)encodeWithCoder:(NSCoder *)encoder;
- (id)initWithCoder:(NSCoder *)decoder;
@end
