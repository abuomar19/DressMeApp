//
//  UIImageAndNSCoder.m
//  DressMe
//  abuomar@usc.edu
//  Created by Jamila Abu-Omar on 12/7/17.
//  Copyright © 2017 Jamila Abu-Omar. All rights reserved.
//

#import "UIImageAndNSCoder.h"

@implementation UIImageAndNSCoder 
- (void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeDataObject:UIImagePNGRepresentation(self)];

}
- (id)initWithCoder:(NSCoder *)decoder{
    return [self initWithData:[decoder decodeDataObject]];

}
@end
