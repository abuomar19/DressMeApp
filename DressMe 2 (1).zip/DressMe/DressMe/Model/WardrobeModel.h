//
//  WardrobeModel.h
//  DressMe
// abuomar@usc.edu
//  Created by Jamila Abu-Omar on 12/5/17.
//  Copyright © 2017 Jamila Abu-Omar. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ClothesModel.h"

//holds all clothing pieces for each user

@interface WardrobeModel : NSObject

+ (instancetype) sharedModel;

- (int)numberOfClothes;

- (void) removeClothingAtIndex:(NSUInteger) index;

- (void) insertClothing:(ClothesModel *)cloth;

- (ClothesModel *)clothingAtIndex: (NSUInteger)index;

@end
