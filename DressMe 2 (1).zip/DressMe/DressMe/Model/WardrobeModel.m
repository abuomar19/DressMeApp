//
//  WardrobeModel.m
//  DressMe
// abuomar@usc.edu
//  Created by Jamila Abu-Omar on 12/5/17.
//  Copyright © 2017 Jamila Abu-Omar. All rights reserved.
//

#import "WardrobeModel.h"


// Private properties are declared in class extension
@interface WardrobeModel ()

@property (nonatomic, strong) NSString *filePath;
@property (nonatomic, strong) NSMutableArray *wardrobe;

@end

@implementation WardrobeModel
//make one instance of the wardrobe to share between self
+ (instancetype)sharedModel{
    static WardrobeModel *wardrobeModel = nil;
    
    // Grand Central Dispatch
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        wardrobeModel= [[WardrobeModel alloc] init];
    });
    
    return wardrobeModel;
}

- (instancetype)init{
    
    self = [super init];
    //check to see if can initialize
    if (self){
        NSLog(@"made it into self ");
        NSArray *documentsDirPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDir = [documentsDirPath objectAtIndex:0];
        // Create a file name for your file
        NSString *filename = @"/Wardrobe.plist";
        
        // Generate the full file path
        _filePath = [documentsDir stringByAppendingString:filename];
        
        NSArray *wardrobeFromDocumentsDir = [NSMutableArray arrayWithContentsOfFile: _filePath];
        
        if (wardrobeFromDocumentsDir != nil){
            NSLog(@"made it into saved data is there ");
            NSLog(@"size of wardrobeFromDocumentsDir%@", wardrobeFromDocumentsDir.count);
            //convert from dictionary to clothesmodel
            for(int i = 0; i < wardrobeFromDocumentsDir.count; i++){
                ClothesModel * piece = [[ClothesModel alloc] initWithType:[wardrobeFromDocumentsDir[i] objectForKey:@"type"] color:[wardrobeFromDocumentsDir[i] objectForKey:@"color"] imageName:UIImage * image owner:[wardrobeFromDocumentsDir[i] objectForKey:@"owner"]];
                [_wardrobe addObject:piece];
                NSLog(@"inside for loop")
            }
            NSLog(@"size of wardrobe : %i", _wardrobe.count);
            // Otherwise, create a empty wardrobe
        } else{
            NSLog(@"made it into else");
            
            ClothesModel *clothes1 = [[ClothesModel alloc] initWithType: @"sweater" color: @"grey" imagename: [UIImage imageNamed: @"womensSweater"] owner:@"jamila"];
             ClothesModel *clothes2 = [[ClothesModel alloc] initWithType: @"shirt" color: @"grey" imagename: [UIImage imageNamed:@"womensShirt"] owner:@"jamila"];
             ClothesModel *clothes3 = [[ClothesModel alloc] initWithType: @"shoes" color: @"white" imagename: [UIImage imageNamed:@"womensShoes"] owner:@"jamila"];
             ClothesModel *clothes4 = [[ClothesModel alloc] initWithType: @"pants" color: @"blue" imagename: [UIImage imageNamed:@"highWaistedJeans"] owner:@"jamila"];
            
            // continue with initialization, populating wardrobe
            _wardrobe = [[NSMutableArray alloc] initWithObjects: [clothes1, clothes2 clothes3, clothes4, nil]];
            NSLog(@"size of wardrobe = %i", _wardrobe.count);
        }
    }
    return self;
    
}
//returns number of clothing pieces
- (int) numberOfClothes{
    return (int)self.wardrobe.count;
}
//allows you to access clothing at certain index
- (ClothesModel *)clothingAtIndex: (NSUInteger)index{
    return self.wardrobe[index];
}
//lets you remove clothing at certian index
- (void) removeClothingAtIndex:(NSUInteger) index{
    [self.wardrobe removeObjectAtIndex:index];
    [self save];
}
//allows you to insert clothing at end of plist
- (void) insertClothing:(ClothesModel*) cloth{
    [self.wardrobe addObject:cloth];
    [self save];
}

//to save to the plist
- (void)save{
    NSMutableArray *savedData = [[NSMutableArray alloc] init];
    NSMutableArray* keys = [[NSMutableArray alloc] initWithObjects:@"color", @"type", @"image", @"owner", nil];
    NSMutableArray* objects;
    for(int i = 0; i < _wardrobe.count; i++){
        objects = [[NSMutableArray alloc] initWithObjects:[self clothingAtIndex:i].color, [self clothingAtIndex:i].type,[self clothingAtIndex:i].color, [self clothingAtIndex:i].owner, nil];
        NSDictionary * clothingPiece = [[NSDictionary alloc] initWithObjects:objects forKeys:keys];
        [savedData addObject:clothingPiece];
    }
    NSLog(@"need to save it");
    NSLog(@"%@",_filePath);
    [savedData writeToFile: _filePath atomically:YES];
}



@end
