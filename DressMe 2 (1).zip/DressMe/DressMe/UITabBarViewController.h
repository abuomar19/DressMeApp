//
//  UITabBarViewController.h
//  DressMe
//
//  Created by Samantha Archie on 12/5/17.
//  Copyright © 2017 Jamila Abu-Omar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITabBarViewController : UIViewController

@end
