//
//  AppDelegate.h
//  DressMe
//  abuomar@usc.edu
//  Created by Jamila Abu-Omar on 11/24/17.
//  Copyright © 2017 Jamila Abu-Omar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

